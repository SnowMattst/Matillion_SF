from abc import abstractmethod, ABC


class AbstractReader(ABC):
    @abstractmethod
    def open_file(self, file_name):
        raise NotImplementedError("Opening of file function needs to be implemented")

    @abstractmethod
    def to_json(self):
        raise NotImplementedError(
            "The opened file contents needs to be converted to json"
        )

    #
    # @abstractmethod
    # def to_dict(self, file_descriptor):
    #     raise NotImplementedError("The opened file contents needs to be converted to dict")
