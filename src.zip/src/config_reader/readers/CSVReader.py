import csv
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any

@dataclass
class CSVReader:
    filepath: str
    delimiter: str = ','
    quotechar: str = '"'
    has_header: bool = True
    data: List[Dict[str, Any]] = field(default_factory=list, init=False)
    headers: Optional[List[str]] = field(default=None, init=False)
    
    def read(self):
        """Reads the CSV file and stores the data in the `data` attribute."""
        with open(self.filepath, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file, delimiter=self.delimiter, quotechar=self.quotechar)
            if self.has_header:
                self.headers = next(reader)
            self.data = [dict(zip(self.headers, row)) if self.headers else row for row in reader]
    
    def get_data(self) -> List[Dict[str, Any]]:
        """Returns the data read from the CSV file."""
        return self.data
    
    def get_headers(self) -> Optional[List[str]]:
        """Returns the headers of the CSV file, if present."""
        return self.headers
    
    def to_json(self) -> str:
        """Converts the data to JSON format."""
        return json.dumps(self.data, indent=4)