import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass

import xmltodict

from ..abstract_reader import AbstractReader


@dataclass
class XMLReader(AbstractReader):
    file_name: str = None

    def __post_init__(self):
        """
        Functions to call post initialization
        :return:
        """
        self.open_file(self.file_name)

    def open_file(self, file_name):
        """
        Open the XML file for further processing
        :param file_name:
        :return:
        """
        self.tree = ET.parse(file_name)
        self.root = self.tree.getroot()
        self.xml_to_string = ET.tostring(self.root, encoding="UTF-8", method="xml")

    def to_json(self):
        """
        Convert the file contents to JSON so that its easy to process
        :return:
        """
        parse_dict = xmltodict.parse(self.xml_to_string)
        json_string = json.dumps(parse_dict)
        return json.loads(json_string)
