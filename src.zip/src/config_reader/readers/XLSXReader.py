import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any

import openpyxl


@dataclass
class XLSXReader:
    filepath: str
    data: List[Dict[str, Any]] = field(default_factory=list, init=False)
    headers: Optional[List[str]] = field(default=None, init=False)
    
    def read(self):
        """Reads the XLSX file and stores the data in the `data` attribute."""
        workbook = openpyxl.load_workbook(self.filepath)
        sheet = workbook.active
        self.headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]
        for row in sheet.iter_rows(min_row=2, values_only=True):
            self.data.append(dict(zip(self.headers, row)))
    
    def get_data(self) -> List[Dict[str, Any]]:
        """Returns the data read from the XLSX file."""
        return self.data
    
    def get_headers(self) -> Optional[List[str]]:
        """Returns the headers of the XLSX file."""
        return self.headers
    
    def to_json(self) -> str:
        """Converts the data to JSON format."""
        return json.dumps(self.data, indent=4)
