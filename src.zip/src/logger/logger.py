import logging

from colorama import Fore, Style


def logger_exception(message):
    """
    Log the message using python logging module.
    :param message:
    :return:
    """
    logging.basicConfig(
        filename="log_exception.txt",
        level=logging.ERROR,
        format="%(asctime)s:%(levelname)s:%(message)s",
    )
    print(f"\n\n{Fore.RED}{message}{Style.RESET_ALL}")
    logging.exception(message)


def logger_debug(message):
    """
    Log the message using python logging module.
    :param message:
    :return:
    """
    logging.basicConfig(
        filename="log_debug.txt",
        level=logging.DEBUG,
        format="%(asctime)s:%(levelname)s:%(message)s",
    )
    print(f"\n\n{Fore.BLUE}{message}{Style.RESET_ALL}")
    logging.debug(message)


def logger_error(message):
    """
    Log the message using python logging module.
    :param message:
    :return:
    """
    logging.basicConfig(
        filename="log_error.txt",
        level=logging.ERROR,
        format="%(asctime)s:%(levelname)s:%(message)s",
    )
    print(f"{Fore.RED}{message}{Style.RESET_ALL}")
    logging.error(message)


def logger_info(message):
    """
    Log the message using python logging module.
    :param message:
    :return:
    """
    logging.basicConfig(
        filename="log_info.txt",
        level=logging.INFO,
        format="%(asctime)s:%(levelname)s:%(message)s",
    )
    print(f"{Fore.GREEN}{message}{Style.RESET_ALL}")
    logging.info(message)
